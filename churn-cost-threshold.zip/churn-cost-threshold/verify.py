#!/usr/bin/env python3
"""Compare a local run against the values published in the manuscript.

    python verify.py --data KDDCup09_churn.arff

Reports, for every configuration present in results/folds, the largest absolute
difference between the local fold values and the published ones. Configurations that have
not been run locally are listed as missing rather than treated as a difference.
"""
import argparse
import json
import warnings

import numpy as np

warnings.filterwarnings("ignore")

from churn.config import RESULTS
from churn.data import load
from churn.tables import fold_metrics

TOL = 5e-5


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True)
    args = ap.parse_args()
    X, y = load(args.data, cache=RESULTS / "clean.pkl")
    pub = json.load(open(RESULTS / "published_reference.json"))
    worst, missing, checked = 0.0, [], 0
    for name, ref in pub["configurations"].items():
        tau = 0.5 if name.endswith("_default_tau05") else None
        base = name[:-len("_tau05")] if name.endswith("_default_tau05") else name
        try:
            M = fold_metrics(y, base, tau)
        except FileNotFoundError:
            missing.append(name)
            continue
        d = np.abs(M - np.array(ref["folds"])).max()
        worst = max(worst, d)
        checked += 1
        flag = "ok" if d < TOL else "DIFFERS"
        print(f"  {name:28s} max |difference| = {d:.2e}  {flag}")
    print(f"\n{checked} configurations compared, largest difference {worst:.2e}")
    if missing:
        print(f"not run locally: {', '.join(missing)}")
    print("reproduced" if checked and worst < TOL else "run more configurations to compare")


if __name__ == "__main__":
    main()
