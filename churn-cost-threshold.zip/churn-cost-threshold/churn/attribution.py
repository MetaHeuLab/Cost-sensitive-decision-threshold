import itertools
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score

from .config import SEED, FOLDS, ATTR_SUBSAMPLE, ATTR_REPEATS
from .data import encode, splits
from .models import build

MEASURES = ["gain", "shap", "perm"]
MEASURE_LABELS = {"gain": "Built-in", "shap": "SHAP", "perm": "Permutation"}


def run(X, y, name="CAT_joint_rime", verbose=True):
    from catboost import Pool
    FOLDS.mkdir(parents=True, exist_ok=True)
    spl = splits(y)
    rng = np.random.default_rng(SEED)
    for j, s in enumerate(spl):
        path = FOLDS / f"ATTR_{j}.npz"
        if path.exists():
            continue
        z = np.load(FOLDS / f"{name}_{j}.npz")["z"]
        Ao, At = encode(X.iloc[s["tr"]], X.iloc[s["te"]])
        yt = y[s["te"]]
        model = build("CAT", z)
        model.fit(Ao, y[s["tr"]])
        sub = rng.choice(len(yt), ATTR_SUBSAMPLE, replace=False)
        A, ys = At[sub], yt[sub]
        shap = np.abs(model.get_feature_importance(Pool(A), type="ShapValues")[:, :-1]).mean(0)
        gain = model.get_feature_importance(type="PredictionValuesChange")
        base = roc_auc_score(ys, model.predict_proba(A)[:, 1])
        perm = np.zeros(A.shape[1])
        for c in range(A.shape[1]):
            drops = []
            for _ in range(ATTR_REPEATS):
                B = A.copy()
                B[:, c] = B[rng.permutation(len(B)), c]
                drops.append(base - roc_auc_score(ys, model.predict_proba(B)[:, 1]))
            perm[c] = np.mean(drops)
        np.savez(path, shap=shap, gain=gain, perm=perm)
        if verbose:
            print(f"  attribution fold {j} done", flush=True)


def collect(variables, n_folds=10):
    data = {m: np.array([np.load(FOLDS / f"ATTR_{j}.npz")[m] for j in range(n_folds)])
            for m in MEASURES}
    stability = {m: float(np.mean([spearmanr(data[m][a], data[m][b]).statistic
                                   for a, b in itertools.combinations(range(n_folds), 2)]))
                 for m in MEASURES}
    return dict(variables=list(variables),
                mean={m: data[m].mean(0).tolist() for m in MEASURES},
                sd={m: data[m].std(0, ddof=1).tolist() for m in MEASURES},
                stability=stability)
