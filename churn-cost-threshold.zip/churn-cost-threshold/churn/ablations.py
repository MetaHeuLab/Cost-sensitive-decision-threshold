import numpy as np
from sklearn.isotonic import IsotonicRegression

from .config import FOLDS, DEPTHS
from .cost import cost, best_threshold, analytic_threshold
from .data import encode, splits
from .models import build


def _selected(n_folds=10, name="CAT_joint_rime"):
    return np.array([np.load(FOLDS / f"{name}_{j}.npz")["z"] for j in range(n_folds)])


def fixed_configuration(n_folds=10, name="CAT_joint_rime"):
    return np.median(_selected(n_folds, name), axis=0)


def depth_sweep(X, y, depths=DEPTHS, name="CAT_joint_rime", verbose=True):
    FOLDS.mkdir(parents=True, exist_ok=True)
    med = fixed_configuration(name=name)
    spl = splits(y)
    for j, s in enumerate(spl):
        for d in depths:
            path = FOLDS / f"SWEEP_d{d}_{j}.npz"
            if path.exists():
                continue
            z = med.copy()
            z[1] = d
            Ai, Av = encode(X.iloc[s["itr"]], X.iloc[s["iva"]])
            Ao, At = encode(X.iloc[s["tr"]], X.iloc[s["te"]])
            m = build("CAT", z)
            m.fit(Ai, y[s["itr"]])
            tau, _ = best_threshold(y[s["iva"]], m.predict_proba(Av)[:, 1])
            m = build("CAT", z)
            m.fit(Ao, y[s["tr"]])
            np.savez(path, te=s["te"], p=m.predict_proba(At)[:, 1], tau=tau)
            if verbose:
                print(f"  depth {d} fold {j} done", flush=True)
    return med


def threshold_transfer(X, y, name="CAT_joint_rime", verbose=True):
    FOLDS.mkdir(parents=True, exist_ok=True)
    Z = _selected(name=name)
    spl = splits(y)
    for j, s in enumerate(spl):
        path = FOLDS / f"TRANSFER_{j}.npz"
        if path.exists():
            continue
        z = Z[j]
        tau_in = float(np.load(FOLDS / f"{name}_{j}.npz")["tau"])
        Ai, Av = encode(X.iloc[s["itr"]], X.iloc[s["iva"]])
        Ao, At = encode(X.iloc[s["tr"]], X.iloc[s["te"]])
        yv, yt = y[s["iva"]], y[s["te"]]
        inner = build("CAT", z)
        inner.fit(Ai, y[s["itr"]])
        pv = inner.predict_proba(Av)[:, 1]
        outer = build("CAT", z)
        outer.fit(Ao, y[s["tr"]])
        pt = outer.predict_proba(At)[:, 1]
        tau_oracle, c_oracle = best_threshold(yt, pt)
        iso = IsotonicRegression(out_of_bounds="clip").fit(pv, yv)
        pc = iso.predict(pt)
        c_iso = cost(yt, pc, analytic_threshold())
        _, c_iso_oracle = best_threshold(yt, pc)
        np.savez(path, tau_in=tau_in, tau_oracle=tau_oracle,
                 c_in=cost(yt, pt, tau_in), c_oracle=c_oracle,
                 c_iso=c_iso, c_iso_oracle=c_iso_oracle,
                 flag_in=float((pt >= tau_in).mean()),
                 flag_oracle=float((pt >= tau_oracle).mean()))
        if verbose:
            d = np.load(path)
            print(f"  transfer fold {j}: tau {d['tau_in']:.4f} vs oracle "
                  f"{d['tau_oracle']:.4f}, shortfall "
                  f"{float(d['c_in'] - d['c_oracle']):+.4f}", flush=True)


def cost_sensitivity(y, ratios=(5, 10, 20), configs=None):
    configs = configs or ["CAT_joint_rime", "CAT_default", "XGB_joint_rime", "LGBM_joint_rime"]
    spl = splits(y)
    out = {}
    for c_fn in ratios:
        row = {}
        trivial = float(np.mean([min(c_fn * y[s["te"]].mean(), 1 - y[s["te"]].mean())
                                 for s in spl]))
        for name in configs:
            thr, iso = [], []
            for j, s in enumerate(spl):
                d = np.load(FOLDS / f"{name}_{j}.npz")
                yt, yv = y[d["te"]], y[d["iva"]]
                tau, _ = best_threshold(yv, d["pv"], c_fn=c_fn)
                thr.append(cost(yt, d["p"], tau, c_fn=c_fn))
                reg = IsotonicRegression(out_of_bounds="clip").fit(d["pv"], yv)
                iso.append(cost(yt, reg.predict(d["p"]),
                                analytic_threshold(c_fn=c_fn), c_fn=c_fn))
            row[name] = dict(threshold=float(np.mean(thr)), isotonic=float(np.mean(iso)))
        row["trivial"] = trivial
        out[str(c_fn)] = row
    return out
