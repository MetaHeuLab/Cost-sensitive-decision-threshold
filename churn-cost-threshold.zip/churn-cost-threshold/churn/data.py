import io
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split

from .config import SEED, N_REPEATS, INNER_TEST_SIZE, MAX_MISSING


def read_arff(path):
    text = Path(path).read_text(encoding="latin-1")
    lines = text.split("\n")
    names, start = [], None
    for i, line in enumerate(lines):
        m = re.match(r"@attribute\s+(\S+)\s+(.*)", line, re.I)
        if m:
            names.append(m.group(1))
        if line.strip().lower() == "@data":
            start = i + 1
            break
    if start is None:
        raise ValueError(f"no @data section found in {path}")
    return pd.read_csv(io.StringIO("\n".join(lines[start:])), header=None,
                       names=names, na_values=["?"], low_memory=False, quotechar="'")


def load(path, cache=None):
    if cache is not None and Path(cache).exists():
        d = pd.read_pickle(cache)
        y = d.pop("__y__").to_numpy()
        return d, y
    df = read_arff(path)
    y = (df["CHURN"] == 1).astype(int).to_numpy()
    X = df.drop(columns="CHURN")
    missing = X.isna().mean()
    X = X[missing[missing <= MAX_MISSING].index]
    X = X.loc[:, X.nunique(dropna=True) > 1]
    if cache is not None:
        d = X.copy()
        d["__y__"] = y
        Path(cache).parent.mkdir(parents=True, exist_ok=True)
        d.to_pickle(cache)
    return X, y


def splits(y):
    out = []
    for r in range(N_REPEATS):
        cv = StratifiedKFold(2, shuffle=True, random_state=SEED + r)
        for k, (tr, te) in enumerate(cv.split(np.zeros(len(y)), y)):
            itr, iva = train_test_split(tr, test_size=INNER_TEST_SIZE,
                                        stratify=y[tr], random_state=SEED + 10 * r + k)
            out.append(dict(rep=r, fold=k, tr=tr, te=te, itr=itr, iva=iva))
    return out


def encode(X_train, X_other):
    A, B = X_train.copy(), X_other.copy()
    for c in A.columns:
        if not pd.api.types.is_numeric_dtype(A[c]):
            freq = A[c].value_counts(normalize=True)
            A[c] = A[c].map(freq).astype(float)
            B[c] = B[c].map(freq).astype(float).fillna(0.0)
    return A.to_numpy(np.float32), B.to_numpy(np.float32)


def summary(X, y):
    from sklearn.metrics import roc_auc_score
    A, _ = encode(X, X.iloc[:1])
    uni = []
    for c in range(A.shape[1]):
        v = A[:, c]
        ok = ~np.isnan(v)
        if ok.sum() > 100 and len(np.unique(v[ok])) > 1:
            a = roc_auc_score(y[ok], v[ok])
            uni.append(max(a, 1 - a))
    n_cat = sum(not pd.api.types.is_numeric_dtype(X[c]) for c in X.columns)
    miss = X.isna().mean()
    return dict(n_customers=len(y), n_churn=int(y.sum()), churn_rate=float(y.mean()),
                n_retained=X.shape[1], n_cat=n_cat, n_num=X.shape[1] - n_cat,
                n_with_missing=int((miss > 0).sum()), median_missing=float(miss.median()),
                max_levels=int(max(X[c].nunique() for c in X.columns
                                   if not pd.api.types.is_numeric_dtype(X[c]))),
                max_uni_auc=float(max(uni)), n_uni_over_060=int(sum(a > 0.60 for a in uni)))
