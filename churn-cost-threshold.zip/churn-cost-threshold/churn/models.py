import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

from .config import MODEL_SEED

LN = np.log

SPACE = {
    "LR":   dict(names=["log10_C", "tau"],
                 lb=[-4, 0.02], ub=[1, 0.6]),
    "EBM":  dict(names=["ln_lr", "max_leaves", "interactions", "min_samples_leaf", "tau"],
                 lb=[LN(0.005), 2, 0, 2, 0.02], ub=[LN(0.1), 4, 5, 50, 0.6]),
    "XGB":  dict(names=["n_estimators", "ln_lr", "max_depth", "min_child_weight",
                        "subsample", "colsample", "reg_lambda", "tau"],
                 lb=[50, LN(0.01), 2, 1, 0.5, 0.3, 0, 0.02],
                 ub=[500, LN(0.3), 10, 50, 1, 1, 30, 0.6]),
    "LGBM": dict(names=["n_estimators", "ln_lr", "num_leaves", "min_child_samples",
                        "subsample", "colsample", "reg_lambda", "tau"],
                 lb=[50, LN(0.01), 3, 5, 0.5, 0.3, 0, 0.02],
                 ub=[500, LN(0.3), 127, 200, 1, 1, 30, 0.6]),
    "CAT":  dict(names=["iterations", "depth", "ln_lr", "l2_leaf_reg", "tau"],
                 lb=[50, 2, LN(0.01), 1, 0.02], ub=[500, 8, LN(0.3), 30, 0.6]),
}

LEARNERS = ["LR", "EBM", "XGB", "LGBM", "CAT"]
LABELS = {"LR": "Logistic regression", "EBM": "Explainable boosting machine",
          "XGB": "XGBoost", "LGBM": "LightGBM", "CAT": "CatBoost"}

_I = lambda v: int(round(v))


def build(name, z):
    S = MODEL_SEED
    if name == "LR":
        return Pipeline([("i", SimpleImputer(strategy="median", add_indicator=True)),
                         ("s", StandardScaler()),
                         ("m", LogisticRegression(C=10 ** z[0], max_iter=2000))])
    if name == "EBM":
        from interpret.glassbox import ExplainableBoostingClassifier
        return ExplainableBoostingClassifier(
            learning_rate=float(np.exp(z[0])), max_leaves=_I(z[1]),
            interactions=_I(z[2]), min_samples_leaf=_I(z[3]),
            outer_bags=4, n_jobs=1, random_state=S)
    if name == "XGB":
        import xgboost as xgb
        return xgb.XGBClassifier(
            n_estimators=_I(z[0]), learning_rate=float(np.exp(z[1])), max_depth=_I(z[2]),
            min_child_weight=float(z[3]), subsample=float(z[4]),
            colsample_bytree=float(z[5]), reg_lambda=float(z[6]),
            tree_method="hist", n_jobs=1, random_state=S, verbosity=0)
    if name == "LGBM":
        import lightgbm as lgb
        return lgb.LGBMClassifier(
            n_estimators=_I(z[0]), learning_rate=float(np.exp(z[1])), num_leaves=_I(z[2]),
            min_child_samples=_I(z[3]), subsample=float(z[4]), subsample_freq=1,
            colsample_bytree=float(z[5]), reg_lambda=float(z[6]),
            n_jobs=1, random_state=S, verbose=-1)
    if name == "CAT":
        from catboost import CatBoostClassifier
        return CatBoostClassifier(
            iterations=_I(z[0]), depth=_I(z[1]), learning_rate=float(np.exp(z[2])),
            l2_leaf_reg=float(z[3]), thread_count=1, random_seed=S, verbose=0)
    raise KeyError(name)


def default(name):
    S = MODEL_SEED
    if name == "LR":
        return Pipeline([("i", SimpleImputer(strategy="median", add_indicator=True)),
                         ("s", StandardScaler()),
                         ("m", LogisticRegression(max_iter=2000))])
    if name == "EBM":
        from interpret.glassbox import ExplainableBoostingClassifier
        return ExplainableBoostingClassifier(outer_bags=4, n_jobs=1, random_state=S)
    if name == "XGB":
        import xgboost as xgb
        return xgb.XGBClassifier(tree_method="hist", n_jobs=1, random_state=S, verbosity=0)
    if name == "LGBM":
        import lightgbm as lgb
        return lgb.LGBMClassifier(n_jobs=1, random_state=S, verbose=-1)
    if name == "CAT":
        from catboost import CatBoostClassifier
        return CatBoostClassifier(thread_count=1, random_seed=S, verbose=0)
    raise KeyError(name)
