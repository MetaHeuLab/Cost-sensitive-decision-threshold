import numpy as np
from sklearn.metrics import (roc_auc_score, f1_score, recall_score,
                             precision_score, accuracy_score)
from .config import C_FN, C_FP


def cost(y, p, tau, c_fn=C_FN, c_fp=C_FP):
    pred = p >= tau
    fn = np.sum((~pred) & (y == 1))
    fp = np.sum(pred & (y == 0))
    return (c_fp * fp + c_fn * fn) / len(y)


def best_threshold(y, p, c_fn=C_FN, c_fp=C_FP):
    order = np.argsort(-p)
    ps, ys = p[order], y[order]
    tp = np.cumsum(ys)
    fp = np.cumsum(1 - ys)
    n_pos = ys.sum()
    fn = n_pos - tp
    c = (c_fp * fp + c_fn * fn) / len(y)
    flag_nobody = c_fn * n_pos / len(y)
    i = int(np.argmin(c))
    if flag_nobody <= c[i]:
        return 1.0 + 1e-9, float(flag_nobody)
    return float(ps[i]), float(c[i])


def analytic_threshold(c_fn=C_FN, c_fp=C_FP):
    return c_fp / (c_fp + c_fn)


def metrics(y, p, tau):
    pred = (p >= tau).astype(int)
    return [cost(y, p, tau),
            roc_auc_score(y, p),
            f1_score(y, pred, zero_division=0),
            recall_score(y, pred, zero_division=0),
            precision_score(y, pred, zero_division=0),
            accuracy_score(y, pred)]


METRIC_NAMES = ["cost", "auc", "f1", "recall", "precision", "accuracy"]
