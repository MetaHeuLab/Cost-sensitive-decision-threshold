import numpy as np

def rime(obj, lb, ub, n_agents=6, max_iter=3, seed=0, w=5.0):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    dim = lb.size
    R = lb + rng.random((n_agents, dim)) * (ub - lb)
    fit = np.array([obj(r) for r in R])
    b = int(np.argmin(fit))
    best, fbest = R[b].copy(), fit[b]
    hist = [fbest]
    for t in range(1, max_iter + 1):
        rime_factor = ((rng.random() - 0.5) * 2
                       * np.cos(np.pi * t / (max_iter / 10))
                       * (1 - np.round(t * w / max_iter) / w))
        E = np.sqrt(t / max_iter)                      
        new = R.copy()
        norm = np.linalg.norm(fit)
        rime_rates = np.zeros_like(fit) if norm == 0 else fit / norm
        for i in range(n_agents):
            for j in range(dim):
                if rng.random() < E:                   
                    new[i, j] = best[j] + rime_factor * (lb[j] + rng.random() * (ub[j] - lb[j]))
                if rng.random() < rime_rates[i]:       
                    new[i, j] = best[j]
        np.clip(new, lb, ub, out=new)
        fnew = np.array([obj(r) for r in new])
        improved = fnew < fit                          
        R[improved], fit[improved] = new[improved], fnew[improved]
        b = int(np.argmin(fit))
        if fit[b] < fbest:
            fbest, best = fit[b], R[b].copy()
        hist.append(fbest)
    return best, fbest, np.array(hist)


def pso(obj, lb, ub, n_agents=6, max_iter=3, seed=0, w=0.7, c1=1.5, c2=1.5):
    r = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    d = lb.size
    X = lb + r.random((n_agents, d)) * (ub - lb)
    V = np.zeros_like(X)
    f = np.array([obj(x) for x in X])
    P, fp = X.copy(), f.copy()
    g, fg = P[np.argmin(fp)].copy(), fp.min()
    for _ in range(max_iter):
        V = w * V + c1 * r.random((n_agents, d)) * (P - X) + c2 * r.random((n_agents, d)) * (g - X)
        X = np.clip(X + V, lb, ub)
        f = np.array([obj(x) for x in X])
        imp = f < fp
        P[imp], fp[imp] = X[imp], f[imp]
        if fp.min() < fg:
            fg, g = fp.min(), P[np.argmin(fp)].copy()
    return g, fg


def de(obj, lb, ub, n_agents=6, max_iter=3, seed=0, F=0.5, CR=0.9):
    r = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    d = lb.size
    X = lb + r.random((n_agents, d)) * (ub - lb)
    f = np.array([obj(x) for x in X])
    for _ in range(max_iter):
        for i in range(n_agents):
            a, b, c = X[r.choice([k for k in range(n_agents) if k != i], 3, replace=False)]
            mutant = np.clip(a + F * (b - c), lb, ub)
            cross = r.random(d) < CR
            cross[r.integers(d)] = True
            u = np.where(cross, mutant, X[i])
            fu = obj(u)
            if fu < f[i]:
                X[i], f[i] = u, fu
    return X[np.argmin(f)], f.min()


def gwo(obj, lb, ub, n_agents=6, max_iter=3, seed=0):
    r = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    d = lb.size
    X = lb + r.random((n_agents, d)) * (ub - lb)
    f = np.array([obj(x) for x in X])
    best, fb = X[np.argmin(f)].copy(), f.min()
    for t in range(max_iter):
        order = np.argsort(f)
        alpha, beta, delta = X[order[0]].copy(), X[order[1]].copy(), X[order[2]].copy()
        a = 2 - 2 * t / max_iter
        for i in range(n_agents):
            new = np.zeros(d)
            for leader in (alpha, beta, delta):
                A = 2 * a * r.random(d) - a
                C = 2 * r.random(d)
                new += leader - A * np.abs(C * leader - X[i])
            X[i] = np.clip(new / 3, lb, ub)
            f[i] = obj(X[i])
            if f[i] < fb:
                fb, best = f[i], X[i].copy()
    return best, fb
