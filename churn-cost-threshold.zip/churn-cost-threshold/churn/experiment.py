import time
import numpy as np
from sklearn.metrics import roc_auc_score

from .config import SEED, BUDGET, N_AGENTS, FOLDS
from .cost import cost, best_threshold
from .data import encode, splits
from .models import SPACE, build, default
from . import optimizers as OPT


def _fit_predict(model, A, ya, B):
    model.fit(A, ya)
    return model.predict_proba(B)[:, 1]


def tag(learner, strategy, optimizer):
    if strategy == "default":
        return f"{learner}_default"
    if strategy == "sequential":
        return f"{learner}_sequential"
    if strategy == "joint_tau":
        return f"{learner}_joint_tau_{optimizer}"
    return f"{learner}_joint_{optimizer}"


def run_fold(X, y, split, learner, strategy="joint", optimizer="rime",
             budget=BUDGET, fold_index=0):
    t0 = time.time()
    Ai, Av = encode(X.iloc[split["itr"]], X.iloc[split["iva"]])
    Ao, At = encode(X.iloc[split["tr"]], X.iloc[split["te"]])
    yi, yv, yo = y[split["itr"]], y[split["iva"]], y[split["tr"]]
    space = SPACE[learner]
    lb, ub = np.array(space["lb"], float), np.array(space["ub"], float)
    history = []

    if strategy == "default":
        pv = _fit_predict(default(learner), Ai, yi, Av)
        tau, _ = best_threshold(yv, pv)
        pt = _fit_predict(default(learner), Ao, yo, At)
        z = np.array([np.nan])
    else:
        cache = {}
        rng = np.random.default_rng(SEED + fold_index)

        def predict(q):
            key = tuple(np.round(q, 6))
            if key not in cache:
                cache[key] = _fit_predict(build(learner, np.r_[q, 0.5]), Ai, yi, Av)
            return cache[key]

        if strategy == "joint":                      
            def objective(q):
                f = best_threshold(yv, predict(q))[1]
                history.append(f)
                return f
            lb0, ub0 = lb[:-1], ub[:-1]
        elif strategy == "sequential":              
            def objective(q):
                f = 1 - roc_auc_score(yv, predict(q))
                history.append(f)
                return f
            lb0, ub0 = lb[:-1], ub[:-1]
        elif strategy == "joint_tau":                
            def objective(z_full):
                key = tuple(np.round(z_full[:-1], 6))
                if key not in cache:
                    cache[key] = _fit_predict(build(learner, z_full), Ai, yi, Av)
                f = cost(yv, cache[key], z_full[-1])
                history.append(f)
                return f
            lb0, ub0 = lb, ub
        else:
            raise ValueError(strategy)

        n_iter = budget // N_AGENTS - 1
        if optimizer == "rime":
            q, _, _ = OPT.rime(objective, lb0, ub0, N_AGENTS, n_iter, seed=SEED + fold_index)
        elif optimizer == "pso":
            q, _ = OPT.pso(objective, lb0, ub0, N_AGENTS, n_iter, seed=SEED + fold_index)
        elif optimizer == "de":
            q, _ = OPT.de(objective, lb0, ub0, N_AGENTS, n_iter, seed=SEED + fold_index)
        elif optimizer == "gwo":
            q, _ = OPT.gwo(objective, lb0, ub0, N_AGENTS, n_iter, seed=SEED + fold_index)
        elif optimizer == "random":
            cand = lb0 + rng.random((budget, len(lb0))) * (ub0 - lb0)
            q = cand[int(np.argmin([objective(v) for v in cand]))]
        elif optimizer == "tpe":
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)
            study = optuna.create_study(
                sampler=optuna.samplers.TPESampler(seed=SEED + fold_index))
            study.optimize(lambda tr: objective(np.array(
                [tr.suggest_float(f"x{i}", lb0[i], ub0[i]) for i in range(len(lb0))])),
                n_trials=budget)
            q = np.array([study.best_params[f"x{i}"] for i in range(len(lb0))])
        else:
            raise ValueError(optimizer)

        z = q if strategy == "joint_tau" else np.r_[q, 0.5]
        key = tuple(np.round(z[:-1], 6))
        pv = cache[key] if key in cache else _fit_predict(build(learner, z), Ai, yi, Av)
        tau = z[-1] if strategy == "joint_tau" else best_threshold(yv, pv)[0]
        pt = _fit_predict(build(learner, z), Ao, yo, At)

    return dict(te=split["te"], iva=split["iva"], p=pt, pv=pv, tau=tau, z=z,
                hist=np.array(history), sec=time.time() - t0)


def run(X, y, learner, strategy="joint", optimizer="rime", budget=BUDGET,
        folds=None, time_limit=None, verbose=True):
    """Run every outer fold, skipping folds already cached in ``results/folds``."""
    FOLDS.mkdir(parents=True, exist_ok=True)
    spl = splits(y)
    name = tag(learner, strategy, optimizer)
    wanted = range(len(spl)) if folds is None else folds
    start = time.time()
    for j in wanted:
        path = FOLDS / f"{name}_{j}.npz"
        if path.exists():
            continue
        if time_limit is not None and time.time() - start > time_limit:
            if verbose:
                print(f"  time limit reached before fold {j}")
            break
        out = run_fold(X, y, spl[j], learner, strategy, optimizer, budget, j)
        np.savez(path, **out)
        if verbose:
            yt = y[out["te"]]
            print(f"  {name} fold {j}: tau={out['tau']:.4f} "
                  f"cost={cost(yt, out['p'], out['tau']):.4f} "
                  f"auc={roc_auc_score(yt, out['p']):.4f} [{out['sec']:.0f}s]", flush=True)
    return name
