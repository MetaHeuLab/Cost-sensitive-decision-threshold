#!/usr/bin/env python3
"""Run the experiments behind the tables. Results are cached per fold, so the script can
be stopped and restarted and will resume where it left off.

    python run_experiments.py --data KDDCup09_churn.arff              # everything
    python run_experiments.py --data ... --stage main                 # Tables 3, 4, 5, 7
    python run_experiments.py --data ... --stage optimizers           # Table 6
    python run_experiments.py --data ... --stage ablations            # Tables 4B, 10
    python run_experiments.py --data ... --stage attribution          # Table 9
    python run_experiments.py --data ... --learner CAT --folds 0 1    # one slice

Approximate single-core cost of a complete run: about eight hours, dominated by the
explainable boosting machine (roughly 150 s per fold) and by the six optimizer
comparisons on CatBoost (roughly 60-90 s per fold each).
"""
import argparse
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

from churn import ablations, attribution, experiment
from churn.config import RESULTS
from churn.data import load

MAIN = ([(L, "default", "rime") for L in ["LR", "EBM", "XGB", "LGBM", "CAT"]]
        + [(L, "joint", "rime") for L in ["LR", "EBM", "XGB", "LGBM", "CAT"]]
        + [("CAT", "sequential", "rime"), ("CAT", "joint_tau", "rime")])
OPTIMIZERS = [("CAT", "joint", o) for o in ["pso", "de", "gwo", "random", "tpe"]]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True, help="path to KDDCup09_churn.arff")
    ap.add_argument("--stage", default="all",
                    choices=["all", "main", "optimizers", "ablations", "attribution"])
    ap.add_argument("--learner", help="restrict to one learner")
    ap.add_argument("--folds", type=int, nargs="+", help="restrict to these outer folds")
    ap.add_argument("--time-limit", type=float, help="seconds per configuration")
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    X, y = load(args.data, cache=RESULTS / "clean.pkl")
    print(f"loaded {X.shape[0]:,} customers, {X.shape[1]} retained variables, "
          f"churn rate {y.mean():.4f}")

    jobs = []
    if args.stage in ("all", "main"):
        jobs += MAIN
    if args.stage in ("all", "optimizers"):
        jobs += OPTIMIZERS
    if args.learner:
        jobs = [j for j in jobs if j[0] == args.learner]
    for learner, strategy, optimizer in jobs:
        print(f"{learner} / {strategy} / {optimizer}")
        experiment.run(X, y, learner, strategy, optimizer,
                       folds=args.folds, time_limit=args.time_limit)

    if args.stage in ("all", "ablations"):
        print("depth sweep")
        ablations.depth_sweep(X, y)
        print("threshold transfer")
        ablations.threshold_transfer(X, y)
    if args.stage in ("all", "attribution"):
        print("attribution")
        attribution.run(X, y)
    print("done")


if __name__ == "__main__":
    main()
