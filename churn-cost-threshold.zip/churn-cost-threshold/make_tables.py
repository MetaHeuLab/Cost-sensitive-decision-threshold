#!/usr/bin/env python3
"""Build every table from the cached fold results.

    python make_tables.py --data KDDCup09_churn.arff

Writes tables/table1_data.csv ... tables/table10_threshold_transfer.csv together with
tables/fold_level_results.csv, which holds the per-fold values behind every reported mean.
"""
import argparse
import warnings

warnings.filterwarnings("ignore")

from churn import tables
from churn.config import RESULTS
from churn.data import load


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True, help="path to KDDCup09_churn.arff")
    args = ap.parse_args()
    X, y = load(args.data, cache=RESULTS / "clean.pkl")
    for path in tables.build_all(X, y):
        print("wrote", path)


if __name__ == "__main__":
    main()
