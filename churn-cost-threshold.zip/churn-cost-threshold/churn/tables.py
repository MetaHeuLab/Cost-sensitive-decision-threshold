import csv
import json
import numpy as np

from .config import FOLDS, TABLES, DEPTHS, BUDGET, N_AGENTS, C_FN, C_FP, SEED
from .cost import cost, metrics, METRIC_NAMES
from .data import splits, summary
from .models import LABELS, SPACE
from . import ablations, attribution
from .statistics import combined_f_test, holm

CONFIGS = {"default_tau05": "Default, τ = 0.5", "default": "Default, tuned τ",
           "joint_rime": "Framework"}


def _folds(name, n=10):
    return [np.load(FOLDS / f"{name}_{j}.npz") for j in range(n)]


def fold_metrics(y, name, tau=None, n=10):
    out = []
    for d in _folds(name, n):
        yt = y[d["te"]]
        t = float(d["tau"]) if tau is None else tau
        out.append(metrics(yt, d["p"], t))
    return np.array(out)


def _w(path, header, rows):
    TABLES.mkdir(parents=True, exist_ok=True)
    with open(TABLES / path, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        wr.writerows(rows)
    return TABLES / path


def table1(X, y):
    s = summary(X, y)
    trivial = float(np.mean([min(C_FN * y[sp["te"]].mean(), 1 - y[sp["te"]].mean())
                             for sp in splits(y)]))
    rows = [["Customers", f"{s['n_customers']:,}"],
            ["Churners", f"{s['n_churn']:,} ({s['churn_rate']:.2%})"],
            ["Variables supplied", "230 (190 numeric, 40 categorical)"],
            ["Variables retained (at most 95% missing)",
             f"{s['n_retained']} ({s['n_num']} numeric, {s['n_cat']} categorical)"],
            ["Retained variables with missing values", s["n_with_missing"]],
            ["Median share of missing values, retained variables", f"{s['median_missing']:.4f}"],
            ["Largest number of categorical levels", f"{s['max_levels']:,}"],
            ["Largest single-variable AUC (screen for post-outcome information)",
             f"{s['max_uni_auc']:.4f}"],
            ["Variables with single-variable AUC above 0.60", s["n_uni_over_060"]],
            [f"Cost of flagging nobody, cost ratio {int(C_FN / C_FP)}", f"{trivial:.4f}"]]
    return _w("table1_data.csv", ["Characteristic", "Value"], rows)


def table2():
    rows = []
    pretty = {"log10_C": "C (inverse regularization), log10",
              "ln_lr": "learning rate, log scale", "tau": "decision threshold τ"}
    for key in ["LR", "EBM", "XGB", "LGBM", "CAT"]:
        sp = SPACE[key]
        for i, nm in enumerate(sp["names"]):
            lo, hi = sp["lb"][i], sp["ub"][i]
            if nm == "ln_lr":
                lo, hi = np.exp(lo), np.exp(hi)
            val = f"{lo:.4g} to {hi:.4g}"
            rows.append([LABELS[key] if i == 0 else "", pretty.get(nm, nm), val])
    rows += [["All searches", "evaluations per search", str(BUDGET)],
             ["", "population size", str(N_AGENTS)],
             ["", f"costs c_FP, c_FN", f"{C_FP:g} and {C_FN:g}"],
             ["", "inner fitting / selection shares", "75% and 25%"],
             ["", "outer resampling", "5 repetitions of stratified 2-fold"],
             ["", "seeds", f"splits {SEED}+rep; inner {SEED}+10·rep+fold; "
                          f"learners 0; searches {SEED}+fold"],
             ["Permutation importance", "customers sampled; repetitions", "5,000; 3"]]
    return _w("table2_search_settings.csv",
              ["Learner or optimizer", "Hyperparameter or setting", "Range or value"], rows)


def table3(y):
    header = ["Learner", "Configuration", "Cost", "AUC", "F1", "Recall", "Precision", "Accuracy"]
    triv = np.array([metrics(y[s["te"]], np.zeros(len(s["te"])), 0.5) for s in splits(y)])
    rows = [["Trivial rule (flag nobody)", "—", f"{triv[:,0].mean():.4f} ({triv[:,0].std(ddof=1):.4f})"]
            + [f"{triv[:, i].mean():.4f}" for i in range(1, 6)]]
    for key in ["LR", "EBM", "XGB", "LGBM", "CAT"]:
        for ci, (cfg, label) in enumerate(CONFIGS.items()):
            name = f"{key}_default" if cfg.startswith("default") else f"{key}_{cfg}"
            tau = 0.5 if cfg == "default_tau05" else None
            try:
                M = fold_metrics(y, name, tau)
            except FileNotFoundError:
                continue
            rows.append([LABELS[key] if ci == 0 else "", label,
                         f"{M[:,0].mean():.4f} ({M[:,0].std(ddof=1):.4f})"]
                        + [f"{M[:, i].mean():.4f}" for i in range(1, 6)])
    return _w("table3_performance.csv", header, rows)


def table4(y):
    header = ["Configuration", "Cost", "AUC", "F1", "Recall"]
    rows = [["A. Threshold procedure", "", "", "", ""]]
    panelA = [("CAT_default", "Default configuration, τ = 0.5", 0.5),
              ("CAT_default", "Default configuration, optimized τ", None),
              ("CAT_sequential", "Sequential: selected by AUC, then τ", None),
              ("CAT_joint_tau_rime", "Joint: τ searched as a coordinate", None),
              ("CAT_joint_rime", "Joint: τ computed exactly (proposed)", None)]
    for name, label, tau in panelA:
        M = fold_metrics(y, name, tau)
        rows.append([label, f"{M[:,0].mean():.4f} ({M[:,0].std(ddof=1):.4f})"]
                    + [f"{M[:, i].mean():.4f}" for i in (1, 2, 3)])
    med = ablations.fixed_configuration()
    rows.append([f"B. Depth, other hyperparameters fixed (iterations {int(round(med[0]))}, "
                 f"learning rate {np.exp(med[2]):.4f} on the log scale, "
                 f"L2 {med[3]:.3f})", "", "", "", ""])
    for d in DEPTHS:
        M = fold_metrics(y, f"SWEEP_d{d}")
        rows.append([f"Depth {d}", f"{M[:,0].mean():.4f} ({M[:,0].std(ddof=1):.4f})"]
                    + [f"{M[:, i].mean():.4f}" for i in (1, 2, 3)])
    return _w("table4_ablations.csv", header, rows)


def table5():
    rows = []
    Z, T = [], []
    for j in range(10):
        d = np.load(FOLDS / f"CAT_joint_rime_{j}.npz")
        z, t = d["z"], float(d["tau"])
        Z.append(z); T.append(t)
        rows.append([j + 1, int(round(z[0])), int(round(z[1])),
                     f"{np.exp(z[2]):.4f}", f"{z[3]:.3f}", f"{t:.4f}"])
    Z = np.array(Z)
    rows.append(["Mean", int(round(Z[:, 0].mean())), f"{Z[:,1].mean():.1f}",
                 f"{np.exp(Z[:,2]).mean():.4f}", f"{Z[:,3].mean():.3f}", f"{np.mean(T):.4f}"])
    return _w("table5_selected_configurations.csv",
              ["Outer fold", "Iterations", "Depth", "Learning rate",
               "L2 leaf regularization", "Threshold τ"], rows)


def table6(y):
    header = ["Optimizer", "Cost", "AUC", "F1", "Best inner cost", "Time (s)"]
    names = [("rime", "RIME"), ("pso", "Particle swarm optimization"),
             ("de", "Differential evolution"), ("gwo", "Grey wolf optimizer"),
             ("random", "Random search"), ("tpe", "Tree-structured Parzen estimator")]
    rows = []
    for opt, label in names:
        name = f"CAT_joint_{opt}"
        M = fold_metrics(y, name)
        ds = _folds(name)
        inner = np.array([np.minimum.accumulate(d["hist"])[-1] for d in ds])
        secs = np.array([float(d["sec"]) for d in ds])
        rows.append([label, f"{M[:,0].mean():.4f} ({M[:,0].std(ddof=1):.4f})",
                     f"{M[:,1].mean():.4f}", f"{M[:,2].mean():.4f}",
                     f"{inner.mean():.4f} ({inner.std(ddof=1):.4f})", f"{secs.mean():.0f}"])
    return _w("table6_optimizers.csv", header, rows)


def table7(y):
    header = ["Comparison", "Δ Cost", "F (cost)", "p (cost)", "Δ AUC", "p (AUC)"]
    ref = fold_metrics(y, "CAT_joint_rime")
    rows = [["A. Framework against default at τ = 0.5", "", "", "", "", ""]]
    famA = []
    for key in ["CAT", "XGB", "LGBM"]:
        fw = fold_metrics(y, f"{key}_joint_rime")[:, 0]
        d05 = fold_metrics(y, f"{key}_default", 0.5)[:, 0]
        F, p = combined_f_test(fw, d05)
        famA.append((LABELS[key], d05.mean() - fw.mean(), F, p))
    for (lab, dc, F, p), adj in zip(famA, holm([x[3] for x in famA])):
        rows.append([lab, f"{dc:+.4f}", f"{F:.3f}", f"{adj:.3e}" if adj < 1e-3 else f"{adj:.3f}",
                     "—", "—"])
    rows.append(["B. Proposed model against", "", "", "", "", ""])
    comp = [("CAT_default", "CatBoost, default, optimized τ", None),
            ("EBM_default", "Explainable boosting machine, default, tuned τ", None),
            ("CAT_sequential", "CatBoost, sequential tuning", None),
            ("CAT_joint_tau_rime", "CatBoost, τ searched as a coordinate", None),
            ("CAT_joint_random", "CatBoost, random search", None),
            ("CAT_joint_tpe", "CatBoost, tree-structured Parzen estimator", None),
            ("CAT_joint_pso", "CatBoost, particle swarm optimization", None),
            ("CAT_joint_de", "CatBoost, differential evolution", None),
            ("CAT_joint_gwo", "CatBoost, grey wolf optimizer", None),
            ("LR_joint_rime", "Logistic regression, framework", None),
            ("EBM_joint_rime", "Explainable boosting machine, framework", None),
            ("XGB_joint_rime", "XGBoost, framework", None),
            ("LGBM_joint_rime", "LightGBM, framework", None)]
    famB = []
    for name, label, tau in comp:
        M = fold_metrics(y, name, tau)
        Fc, pc = combined_f_test(ref[:, 0], M[:, 0])
        Fa, pa = combined_f_test(ref[:, 1], M[:, 1])
        famB.append([label, M[:, 0].mean() - ref[:, 0].mean(),
                     ref[:, 1].mean() - M[:, 1].mean(), Fc, pc, Fa, pa])
    triv = np.array([metrics(y[s["te"]], np.zeros(len(s["te"])), 0.5) for s in splits(y)])
    Fc, pc = combined_f_test(ref[:, 0], triv[:, 0])
    famB.append(["Trivial rule (flag nobody)", triv[:, 0].mean() - ref[:, 0].mean(),
                 None, Fc, pc, None, None])
    adj_c = holm([r[4] for r in famB])
    aucs = [i for i, r in enumerate(famB) if r[6] is not None]
    adj_a = holm([famB[i][6] for i in aucs])
    amap = {i: v for i, v in zip(aucs, adj_a)}
    for i, r in enumerate(famB):
        rows.append([r[0], f"{r[1]:+.4f}", f"{r[3]:.3f}",
                     f"{adj_c[i]:.3e}" if adj_c[i] < 1e-3 else f"{adj_c[i]:.3f}",
                     "—" if r[2] is None else f"{r[2]:+.4f}",
                     "—" if i not in amap else
                     (f"{amap[i]:.3e}" if amap[i] < 1e-3 else f"{amap[i]:.3f}")])
    return _w("table7_significance.csv", header, rows)


def table8(y):
    S = ablations.cost_sensitivity(y)
    header = ["Configuration", "Optimized threshold", "Isotonic calibration with Eq. (4)"]
    labels = {"CAT_joint_rime": "CatBoost, proposed framework",
              "CAT_default": "CatBoost, default configuration",
              "XGB_joint_rime": "XGBoost, framework", "LGBM_joint_rime": "LightGBM, framework"}
    rows = []
    for ratio, row in S.items():
        rows.append([f"Cost ratio {ratio}", "", ""])
        rows.append(["Trivial rule (cheaper of flag nobody and flag everybody)",
                     f"{row['trivial']:.4f}", "—"])
        for k, lab in labels.items():
            rows.append([lab, f"{row[k]['threshold']:.4f}", f"{row[k]['isotonic']:.4f}"])
    return _w("table8_cost_ratios.csv", header, rows)


def table9(X):
    A = attribution.collect(X.columns)
    g = np.array(A["mean"]["gain"]); s = np.array(A["mean"]["shap"]); p = np.array(A["mean"]["perm"])
    rank = lambda a: np.argsort(np.argsort(-a)) + 1
    rg, rs, rp = rank(g), rank(s), rank(p)
    order = np.argsort(-g)[:10]
    rows = [[A["variables"][i], f"{g[i]:.4f}", rg[i], f"{s[i]:.4f}", rs[i],
             f"{p[i]:.4f}", rp[i]] for i in order]
    rows.append(["Rank stability across folds", f"{A['stability']['gain']:.3f}", "",
                 f"{A['stability']['shap']:.3f}", "", f"{A['stability']['perm']:.3f}", ""])
    return _w("table9_attribution.csv",
              ["Variable", "Built-in", "Rank", "SHAP", "Rank", "Permutation", "Rank"], rows)


def table10():
    D = [np.load(FOLDS / f"TRANSFER_{j}.npz") for j in range(10)]
    k = lambda n: np.array([float(d[n]) for d in D])
    ti, to, ci, co = k("tau_in"), k("tau_oracle"), k("c_in"), k("c_oracle")
    gap, gi = ci - co, k("c_iso") - k("c_iso_oracle")
    rows = [[j + 1, f"{ti[j]:.4f}", f"{to[j]:.4f}", f"{ci[j]:.4f}", f"{co[j]:.4f}",
             f"{gap[j]:+.4f}", f"{gi[j]:+.4f}"] for j in range(10)]
    rows.append(["Mean", f"{ti.mean():.4f}", f"{to.mean():.4f}", f"{ci.mean():.4f}",
                 f"{co.mean():.4f}", f"{gap.mean():+.4f}", f"{gi.mean():+.4f}"])
    rows.append(["Standard deviation", f"{ti.std(ddof=1):.4f}", f"{to.std(ddof=1):.4f}",
                 f"{ci.std(ddof=1):.4f}", f"{co.std(ddof=1):.4f}",
                 f"{gap.std(ddof=1):.4f}", f"{gi.std(ddof=1):.4f}"])
    return _w("table10_threshold_transfer.csv",
              ["Outer fold", "Transferred τ", "Oracle τ", "Cost, transferred",
               "Cost, oracle", "Shortfall", "Isotonic shortfall"], rows)


def fold_level_csv(y):
    names = sorted({f.name.rsplit("_", 1)[0] for f in FOLDS.glob("*.npz")
                    if not f.name.startswith(("ATTR", "TRANSFER"))})
    rows = []
    for name in names:
        try:
            M = fold_metrics(y, name)
        except Exception:
            continue
        for j, r in enumerate(M):
            rows.append([name, j + 1] + [round(v, 6) for v in r])
    return _w("fold_level_results.csv", ["configuration", "outer_fold"] + METRIC_NAMES, rows)


def build_all(X, y):
    made = [table1(X, y), table2(), table3(y), table4(y), table5(), table6(y),
            table7(y), table8(y), table9(X), table10(), fold_level_csv(y)]
    return made
