from pathlib import Path

SEED = 2026                 
MODEL_SEED = 0            
C_FN = 10.0                
C_FP = 1.0                 

N_REPEATS = 5              
INNER_TEST_SIZE = 0.25      
BUDGET = 24                
N_AGENTS = 6                
MAX_MISSING = 0.95          
DEPTHS = (2, 3, 4, 6, 8)    
ATTR_SUBSAMPLE = 5000      
ATTR_REPEATS = 3           

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FOLDS = RESULTS / "folds"
TABLES = ROOT / "tables"
