import numpy as np
from scipy import stats


def combined_f_test(a, b):
    p = (np.asarray(a, float) - np.asarray(b, float)).reshape(5, 2)
    m = p.mean(1, keepdims=True)
    s2 = ((p - m) ** 2).sum(1)
    if s2.sum() == 0:
        return float("nan"), 1.0
    F = (p ** 2).sum() / (2 * s2.sum())
    return float(F), float(stats.f.sf(F, 10, 5))


def holm(pvalues):
    p = np.asarray(pvalues, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * p[i]))
        adj[i] = running
    return adj
